timestamp_count = 8928
free_count = int(timestamp_count*0.95 + 0.5)
print(free_count)